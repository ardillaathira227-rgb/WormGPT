const { createCanvas } = require('canvas');
const fs = require('fs');

// Buat canvas 64x64
const canvas = createCanvas(64, 64);
const ctx = canvas.getContext('2d');

// Background hitam
ctx.fillStyle = '#0a0a0a';
ctx.fillRect(0, 0, 64, 64);

// Gambar worm hijau
ctx.fillStyle = '#00ff00';
ctx.beginPath();
ctx.ellipse(32, 32, 20, 12, 0, 0, Math.PI * 2);
ctx.fill();

// Mata
ctx.fillStyle = '#ffffff';
ctx.beginPath();
ctx.arc(40, 28, 4, 0, Math.PI * 2);
ctx.arc(40, 36, 4, 0, Math.PI * 2);
ctx.fill();

// Simpan sebagai favicon.ico (PNG format)
const buffer = canvas.toBuffer('image/png');
fs.writeFileSync('public/favicon.ico', buffer);
fs.writeFileSync('public/favicon.png', buffer);

console.log('✅ Favicon generated: public/favicon.ico');