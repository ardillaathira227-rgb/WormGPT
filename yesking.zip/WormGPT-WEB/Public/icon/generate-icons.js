const { createCanvas } = require('canvas');
const fs = require('fs');
const path = require('path');

// Buat folder icons jika belum ada
const iconsDir = path.join(__dirname, 'public/icons');
if (!fs.existsSync(iconsDir)) {
  fs.mkdirSync(iconsDir, { recursive: true });
}

// Daftar ukuran icon yang dibutuhkan
const sizes = [72, 96, 128, 144, 152, 192, 384, 512];

// Warna tema
const backgroundColor = '#0a0a0a';
const wormColor = '#00ff00';
const textColor = '#ffffff';

sizes.forEach(size => {
  const canvas = createCanvas(size, size);
  const ctx = canvas.getContext('2d');
  
  // Background
  ctx.fillStyle = backgroundColor;
  ctx.fillRect(0, 0, size, size);
  
  // Gambar worm emoji style
  ctx.fillStyle = wormColor;
  
  // Body worm (beberapa lingkaran terhubung)
  const segmentCount = 5;
  const segmentRadius = size / 8;
  
  for (let i = 0; i < segmentCount; i++) {
    const x = size / 2 + Math.sin(i * 0.8) * (size / 4);
    const y = size / 2 + i * (segmentRadius / 2);
    
    ctx.beginPath();
    ctx.arc(x, y, segmentRadius, 0, Math.PI * 2);
    ctx.fill();
  }
  
  // Mata (hanya untuk icon besar)
  if (size >= 128) {
    ctx.fillStyle = textColor;
    ctx.beginPath();
    ctx.arc(size / 2 + size / 10, size / 2 - size / 10, size / 20, 0, Math.PI * 2);
    ctx.arc(size / 2 + size / 10, size / 2, size / 20, 0, Math.PI * 2);
    ctx.fill();
  }
  
  // Simpan icon
  const buffer = canvas.toBuffer('image/png');
  fs.writeFileSync(path.join(iconsDir, `icon-${size}x${size}.png`), buffer);
  console.log(`✅ Generated icon-${size}x${size}.png`);
});

// Buat juga favicon.ico (multi-size)
const faviconCanvas = createCanvas(64, 64);
const faviconCtx = faviconCanvas.getContext('2d');

faviconCtx.fillStyle = backgroundColor;
faviconCtx.fillRect(0, 0, 64, 64);

faviconCtx.fillStyle = wormColor;
faviconCtx.font = 'bold 48px Arial';
faviconCtx.textAlign = 'center';
faviconCtx.textBaseline = 'middle';
faviconCtx.fillText('🐛', 32, 32);

const faviconBuffer = faviconCanvas.toBuffer('image/png');
fs.writeFileSync(path.join(__dirname, 'public/favicon.ico'), faviconBuffer);
fs.writeFileSync(path.join(__dirname, 'public/favicon-32x32.png'), faviconBuffer);

console.log('✅ Generated favicon.ico and favicon-32x32.png');
console.log('🎨 All PWA icons generated successfully!');