<div align="center">
  
  ![XPrime Banner](https://img.shields.io/badge/XPRIME💫-UNRESTRICTED_AI-black?style=for-the-badge&logo=ghost&logoColor=#00ff00)
  
  <h1>🐛 XPRIME - Unfiltered AI Assistant</h1>
  
  <p>
    <strong>Technical AI without limitations • Full-stack deployment • Enterprise ready</strong>
  </p>
  
  <p>
    <a href="#-features">Features</a> •
    <a href="#-quick-deploy">Deploy</a> •
    <a href="#-architecture">Architecture</a> •
    <a href="#-api-reference">API</a> •
    <a href="#-security">Security</a>
  </p>
  
  ![Version](https://img.shields.io/badge/version-1.0.0-green)
  ![License](https://img.shields.io/badge/license-MIT-blue)
  ![Node](https://img.shields.io/badge/node-%3E%3D18.0.0-success)
  ![React](https://img.shields.io/badge/react-18.2.0-61dafb)
  ![Status](https://img.shields.io/badge/status-production_ready-brightgreen)
  
</div>

---

## 🚀 **What is XPrime?**

**XPrime** is a full-stack AI assistant platform designed for **unrestricted technical queries**. Built with cutting-edge security and deployment practices, it provides unfiltered access to AI capabilities for developers, security researchers, and technical professionals.

> **Disclaimer**: This project is for **educational and authorized testing purposes only**. Users are responsible for complying with all applicable laws and regulations.

## ✨ **Features**

### **🎯 Core Capabilities**
- **Unfiltered AI Responses** - No content restrictions or moral policing
- **Technical Focus** - Cybersecurity, programming, network analysis
- **Full-Stack Architecture** - React frontend + Express backend
- **Enterprise Security** - Rate limiting, CORS, helmet, environment isolation

### **⚡ Technical Stack**
| Layer | Technology | Purpose |
|-------|------------|---------|
| **Frontend** | React 18, CSS3 | Modern UI with real-time updates |
| **Backend** | Express.js, Node.js | Secure API gateway |
| **AI Engine** | Google Gemini Pro | Advanced AI generation |
| **Security** | Helmet, Rate Limit, CORS | Production-grade protection |
| **Deployment** | Railway.app | One-click global deployment |

### **🔐 Security Features**
- API key isolation (server-side only)
- Request rate limiting (100/15min)
- CORS with origin validation
- Input sanitization & validation
- HTTPS enforcement in production
- No client-side exposure of sensitive data

## 🛠️ **Quick Deploy**

### **Option 1: Railway (Recommended)**
```bash
# Clone repository
git clone https://github.com/yourusername/xprime-ai.git
cd xprime-ai

# Deploy with one command
railway login && railway up --detach